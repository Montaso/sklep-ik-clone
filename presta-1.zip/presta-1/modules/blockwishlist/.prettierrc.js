module.exports = {
  htmlWhitespaceSensitivity: 'ignore',
  semi: true,
  singleQuote: true,
  vueIndentScriptAndStyle: true,
  trailingComma: 'none'
};
